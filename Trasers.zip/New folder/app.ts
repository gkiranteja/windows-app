import { app, BrowserWindow, Menu, screen, ipcMain } from 'electron';
const {autoUpdater} = require("electron-updater");
const log = require('electron-log');
import * as path from 'path';
import * as url from 'url';
import * as fs from 'fs';

let win, serve;
const args = process.argv.slice(1);
serve = args.some(val => val === '--serve');
autoUpdater.logger = log;
autoUpdater.logger.transports.file.level = 'info';

try {
  require('dotenv').config();
} catch {
  console.log('asar');
}

function createWindow() {
  // updater.init('http://localhost/Trasers/updates.json');

  const electronScreen = screen;
  const size = electronScreen.getPrimaryDisplay().workAreaSize;

  // Create the browser window.
  //we added minWidth: 1037, minHeight: 804 to restrict the user to resize(1024x768) the window
  win = new BrowserWindow({
    x: 0,
    y: 0,
    width: size.width,
    height: size.height,
    minWidth: 1037, minHeight: 804,
    icon: path.join(__dirname, './150-150.png'),
    webPreferences: { webSecurity: false, allowRunningInsecureContent: true }
  });
  win.setMenu(null);

  if (serve) {
    require('electron-reload')(__dirname, {
      electron: require(`${__dirname}/node_modules/electron`)
    });
    win.loadURL('http://localhost:4200');
  } else {
    win.loadURL(url.format({
      pathname: path.join(__dirname, 'dist/index.html'),
      protocol: 'file:',
      slashes: true
    }));
  }

  ipcMain.on('call-main-process', function (event, arg) {
    // win.webContents.send('child-process-name', arg);
  });

  win.webContents.openDevTools();

  // Emitted when the window is closed.
  win.on('closed', () => {
    // Dereference the window object, usually you would store window
    // in an array if your app supports multi windows, this is the time
    // when you should delete the corresponding element.
    win = null;
  });

}

try {

  // This method will be called when Electron has finished
  // initialization and is ready to create browser windows.
  // Some APIs can only be used after this event occurs.
  app.on('ready', createWindow);

  const { remote } = require('electron');
  const updater = remote.require('electron-simple-updater');

  // var updater = require('electron-simple-updater');
  updater.init({
    checkUpdateOnStart: true,
    autoDownload: true,
    logger: 'console',
    url: 'http://localhost/Trasers/updates.json'
  });
  
  // Quit when all windows are closed.
  app.on('window-all-closed', () => {
    // On OS X it is common for applications and their menu bar
    // to stay active until the user quits explicitly with Cmd + Q
    if (process.platform !== 'darwin') {
      app.quit();
    }
  });

  app.on('activate', () => {
    // On OS X it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (win === null) {
      createWindow();
    }
  });

} catch (e) {
  // Catch Error
  // throw e;
}
