import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-terms-and-polacy',
  templateUrl: './terms-and-polacy.component.html',
  styleUrls: ['./terms-and-polacy.component.scss']
})
export class TermsAndPolacyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  termsAnsPolacy(){
  


  }

}
