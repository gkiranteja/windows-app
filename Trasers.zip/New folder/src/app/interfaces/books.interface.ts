export interface flipPage{
    totalCount: number,
    currentPageNumber: number
}