export const CONF_LOCAL = {
  production: false,
  environment: 'LOCAL'
};
