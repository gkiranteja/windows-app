export const CONF_PROD = {
  production: true,
  environment: 'PROD'
};
