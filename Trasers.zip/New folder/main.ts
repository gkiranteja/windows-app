const {app, BrowserWindow, Menu, protocol, 
ipcMain, dialog } = require('electron');
log = require('electron-log');
const {autoUpdater} = require("electron-updater");
const path = require('path');
const url = require('url');

const args = process.argv.slice(1);
const serve = args.some(val => val === '--serve');

try {
  require('dotenv').config();
} catch {
  console.log('asar');
}

autoUpdater.logger = log;
autoUpdater.logger.transports.file.level = 'debug';
log.info('App starting...');

let template = []
if (process.platform === 'darwin') {
  // OS X
  const name = app.getName();
  template.unshift({
    label: name,
    submenu: [
      {
        label: 'About ' + name,
        role: 'about'
      },
      {
        label: 'Quit',
        accelerator: 'Command+Q',
        click() { app.quit(); }
      },
    ]
  })
}

let win;

function sendStatusToWindow(text) {
  log.info(text);
  win.webContents.send('message', text);
}
function createDefaultWindow() {
  const electronScreen = require('electron').screen;
  const size = electronScreen.getPrimaryDisplay().workAreaSize;
  //we added minWidth: 1037, minHeight: 804 to restrict the user to resize(1024x768) the window
  win = new BrowserWindow({
    x: 0, y: 0,
    width: size.width, height: size.height,
    minWidth: 1037, minHeight: 804,
    icon: path.join(__dirname, './150-150.png'),
    webPreferences: { webSecurity: false, allowRunningInsecureContent: true }
  });
  // win.webContents.openDevTools();
  win.on('closed', () => {
    win = null;
  });

  if (serve) {
    require('electron-reload')(__dirname, {
      electron: require(`${__dirname}/node_modules/electron`)
    });
    win.loadURL('http://localhost:4200');
  } else {
    log.info(__dirname);
    win.loadURL(`file://${__dirname}/../dist/index.html`);
  }
}
autoUpdater.on('checking-for-update', () => {
  sendStatusToWindow('Checking for update...');
})
autoUpdater.on('update-available', (ev, info) => {
  dialog.showMessageBox(win, {
    title: "Update available", message: "New version is available for download. Click OK to download in the background."
  });
  sendStatusToWindow('Update available.');
})
autoUpdater.on('update-not-available', (ev, info) => {
  sendStatusToWindow('Update not available.');
})
autoUpdater.on('error', (ev, err) => {
  sendStatusToWindow('Error in auto-updater.');
})
autoUpdater.on('download-progress', (ev, progressObj) => {
  win.setProgress(progressObj.percent);
})
autoUpdater.on('update-downloaded', (ev, info) => {
  sendStatusToWindow('Update downloaded; will install in 5 seconds');
});
app.on('ready', function() {
  // Create the Menu
  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);

  createDefaultWindow();
});

app.on('window-all-closed', () => {
  app.quit();
});

autoUpdater.on('update-downloaded', (ev, info) => {
  dialog.showMessageBox(win, {
    title: "Update available", message: "New version is ready to install.",
    buttons:['Restart']
  });
  setTimeout(function() {
    autoUpdater.quitAndInstall();  
  }, 3000)
})

app.on('ready', function()  {
  autoUpdater.checkForUpdates();
});
